package com.example.exdado

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
